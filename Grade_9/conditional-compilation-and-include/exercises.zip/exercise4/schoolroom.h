#ifndef _SCHOOLROOM_H
#define  _SCHOOLROOM_H

#include "person.h"
struct SchoolRoom
{
    int roomnumber;
    struct Person studentsnow[50];
};

#endif