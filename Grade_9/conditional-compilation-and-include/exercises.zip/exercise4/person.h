#ifndef _PERSON_H
#define _PERSON_H

struct Person {
  char firstname[20];
  char secondname[20];
  char surname[20];
  int year;
};

#endif