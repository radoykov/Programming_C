#include <stdio.h>
#include "schoolclass.h"
#include "schoolroom.h"
struct School
    {
        struct SchoolClass clases[20];
        struct SchoolRoom rooms[10];
    };
int main() 
{
    struct School sl;
    
    
    return 0;
}